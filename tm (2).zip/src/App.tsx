"use client"

import { useState, useEffect } from "react"
import { LoginPage } from "./components/LoginPage"
import { HomePage } from "./components/HomePage"
import { DistributionApp } from "./components/DistributionApp"
import { AbsenceManagement } from "./components/AbsenceManagement"
import { DataImport } from "./components/DataImport"
import { Navbar } from "./components/Navbar"
import { Footer } from "./components/Footer"
import { getProfessors, getStudents } from "./services/api"

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [currentPage, setCurrentPage] = useState<"home" | "supervision" | "import" | "absences" | "documents">("home")
  const [professors, setProfessors] = useState<string[]>([])
  const [students, setStudents] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  // جلب البيانات من الخادم عند تحميل التطبيق
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)

        // جلب الأساتذة
        const professorsData = await getProfessors()
        setProfessors(professorsData.map((p: any) => p.name))

        // جلب الطلاب
        const studentsData = await getStudents()
        setStudents(studentsData.map((s: any) => s.name))
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    if (isLoggedIn) {
      fetchData()
    }
  }, [isLoggedIn])

  const handleLogin = () => {
    setIsLoggedIn(true)
  }

  const handleNavigate = (page: string) => {
    setCurrentPage(page as any)
  }

  const handleImportData = (importedProfessors: string[], importedStudents: string[]) => {
    setProfessors(importedProfessors)
    setStudents(importedStudents)
    setCurrentPage("home")
  }

  console.log("App rendering, current page:", currentPage)

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onNavigate={handleNavigate} currentPage={currentPage} />
      <main className="flex-grow">
        {loading ? (
          <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-800">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <h1 className="text-2xl font-bold mb-4">جاري تحميل البيانات...</h1>
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            </div>
          </div>
        ) : (
          <>
            {currentPage === "home" && <HomePage onNavigate={handleNavigate} />}
            {currentPage === "supervision" && <DistributionApp professors={professors} onNavigate={handleNavigate} />}
            {currentPage === "import" && <DataImport onImport={handleImportData} />}
            {currentPage === "absences" && <AbsenceManagement professors={professors} students={students} />}
            {currentPage === "documents" && (
              <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-800">
                <div className="bg-white p-8 rounded-lg shadow-lg">
                  <h1 className="text-2xl font-bold mb-4">صفحة المطبوعات التنظيمية</h1>
                  <p>هذه الصفحة قيد التطوير</p>
                </div>
              </div>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  )
}

export default App

