import axios from "axios"
import type { Professor, Student, Absence, Distribution } from "../types"

const API_URL = "http://localhost:5000/api"

const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
})

// خدمات الأساتذة
export const getProfessors = async (): Promise<Professor[]> => {
  const response = await api.get("/professors")
  return response.data
}

export const addProfessors = async (names: string[]): Promise<{ message: string; professors: Professor[] }> => {
  const response = await api.post("/professors/batch", { names })
  return response.data
}

// خدمات الطلاب
export const getStudents = async (): Promise<Student[]> => {
  const response = await api.get("/students")
  return response.data
}

export const addStudents = async (names: string[]): Promise<{ message: string; students: Student[] }> => {
  const response = await api.post("/students/batch", { names })
  return response.data
}

// خدمات الغيابات
export const getAbsences = async (): Promise<Absence[]> => {
  const response = await api.get("/absences")
  return response.data
}

export const addAbsence = async (
  name: string,
  type: "absence" | "late",
  category: "professor" | "student",
): Promise<Absence> => {
  const response = await api.post("/absences", { name, type, category })
  return response.data
}

// خدمات التوزيعات
export const getDistributions = async (): Promise<Distribution[]> => {
  const response = await api.get("/distributions")
  return response.data
}

export const createDistribution = async (days: any[]): Promise<Distribution> => {
  const response = await api.post("/distributions", { days })
  return response.data
}

export const updateDistribution = async (id: string, days: any[]): Promise<Distribution> => {
  const response = await api.put(`/distributions/${id}`, { days })
  return response.data
}

export default api

