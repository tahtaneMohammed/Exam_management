import React from "react"
import ReactDOM from "react-dom/client"
import App from "./App"
import "./index.css"

console.log("main.tsx: Starting application")

// Make sure the root element exists
const rootElement = document.getElementById("root")
if (!rootElement) {
  console.error("Failed to find the root element")
  document.body.innerHTML = '<div id="root"></div>'
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

