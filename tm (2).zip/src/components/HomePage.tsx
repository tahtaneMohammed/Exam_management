import { Card, CardContent } from "./ui/card"
import { Button } from "./ui/button"
import { FileText, UserCheck, UserMinus, Database } from "lucide-react"

interface HomePageProps {
  onNavigate: (page: string) => void
}

export function HomePage({ onNavigate }: HomePageProps) {
  console.log("HomePage rendering")

  const menuItems = [
    { icon: Database, text: "استيراد البيانات", action: () => onNavigate("import") },
    { icon: UserCheck, text: "تسيير الحراسة", action: () => onNavigate("supervision") },
    { icon: UserMinus, text: "تسيير الغيابات", action: () => onNavigate("absences") },
    { icon: FileText, text: "مطبوعات تنظيمية", action: () => onNavigate("documents") },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-indigo-800 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-white mb-8 text-center">تطبيق تسيير الامتحانات المدرسية</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {menuItems.map((item, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
            <CardContent className="p-6">
              <Button
                onClick={item.action}
                className="w-full h-full flex flex-col items-center justify-center space-y-4 bg-white hover:bg-gray-50 text-gray-800"
              >
                <item.icon className="w-12 h-12" />
                <span className="text-lg font-semibold">{item.text}</span>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

