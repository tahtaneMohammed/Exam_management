import { Mail, Phone, Globe } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-4 text-sm">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div>
          <p>© {new Date().getFullYear()} نظام إدارة الامتحانات. جميع الحقوق محفوظة.</p>
        </div>
        <div className="flex space-x-4">
          <span className="flex items-center">
            <Mail className="h-4 w-4 mr-1" /> contact@exam-system.com
          </span>
          <span className="flex items-center">
            <Phone className="h-4 w-4 mr-1" /> +123 456 7890
          </span>
          <span className="flex items-center">
            <Globe className="h-4 w-4 mr-1" /> www.exam-system.com
          </span>
        </div>
      </div>
    </footer>
  )
}

