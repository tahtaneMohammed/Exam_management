import { Button } from "./ui/button"
import { Home, FileText, UserCheck, UserMinus, FileUp } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip"

interface NavbarProps {
  onNavigate: (page: string) => void
  currentPage: string
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  console.log("Navbar rendering, current page:", currentPage)

  const navItems = [
    { icon: Home, text: "الرئيسية", page: "home" },
    { icon: FileUp, text: "استيراد البيانات", page: "import" },
    { icon: UserCheck, text: "تسيير الحراسة", page: "supervision" },
    { icon: UserMinus, text: "تسيير الغيابات", page: "absences" },
    { icon: FileText, text: "مطبوعات تنظيمية", page: "documents" },
  ]

  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <span className="text-xl font-bold text-blue-600">نظام إدارة الامتحانات</span>
      </div>
      <div className="flex space-x-2">
        <TooltipProvider>
          {navItems.map((item) => (
            <Tooltip key={item.page}>
              <TooltipTrigger asChild>
                <Button
                  variant={currentPage === item.page ? "default" : "ghost"}
                  className="w-12 h-12 p-0 mx-1"
                  onClick={() => onNavigate(item.page)}
                >
                  <item.icon className="h-6 w-6" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{item.text}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </TooltipProvider>
      </div>
    </nav>
  )
}

