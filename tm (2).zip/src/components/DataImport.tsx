"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "./ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "./ui/card"
import { Upload } from "lucide-react"
import * as XLSX from "xlsx"
import { addProfessors, addStudents } from "../services/api"

interface DataImportProps {
  onImport: (professors: string[], students: string[]) => void
}

export function DataImport({ onImport }: DataImportProps) {
  const [professorsFile, setProfessorsFile] = useState<File | null>(null)
  const [studentsFile, setStudentsFile] = useState<File | null>(null)
  const [error, setError] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: "professors" | "students") => {
    const file = e.target.files?.[0]
    if (!file) {
      setError("الرجاء اختيار ملف Excel.")
      return
    }

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: "buffer" })
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as string[][]

      if (!jsonData || jsonData.length === 0) {
        setError("الملف فارغ أو لا يحتوي على بيانات.")
        return
      }

      const names = jsonData.flat().filter(Boolean)

      if (names.length === 0) {
        setError("لم يتم العثور على أي أسماء في الملف.")
        return
      }

      if (type === "professors") {
        setProfessorsFile(file)
      } else {
        setStudentsFile(file)
      }

      setError("")
    } catch (e) {
      setError("حدث خطأ أثناء قراءة الملف. الرجاء التأكد من أن الملف بتنسيق Excel صالح.")
    }
  }

  const handleImport = async () => {
    if (!professorsFile || !studentsFile) {
      setError("الرجاء تحميل كلا الملفين قبل الاستيراد.")
      return
    }

    setLoading(true)
    setError("")

    try {
      const professorsData = await professorsFile.arrayBuffer()
      const studentsData = await studentsFile.arrayBuffer()

      const professorsWorkbook = XLSX.read(professorsData, { type: "buffer" })
      const studentsWorkbook = XLSX.read(studentsData, { type: "buffer" })

      const professorsSheet = professorsWorkbook.Sheets[professorsWorkbook.SheetNames[0]]
      const studentsSheet = studentsWorkbook.Sheets[studentsWorkbook.SheetNames[0]]

      const professors = XLSX.utils.sheet_to_json(professorsSheet, { header: 1 }).flat().filter(Boolean) as string[]
      const students = XLSX.utils.sheet_to_json(studentsSheet, { header: 1 }).flat().filter(Boolean) as string[]

      // إرسال البيانات إلى الخادم
      await addProfessors(professors)
      await addStudents(students)

      onImport(professors, students)
      setError("")
    } catch (e) {
      console.error("Error importing data:", e)
      setError("حدث خطأ أثناء استيراد البيانات. الرجاء المحاولة مرة أخرى.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-800 to-indigo-900 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-5xl font-extrabold text-white mb-12 text-center tracking-tight">استيراد البيانات</h1>
        <Card className="shadow-2xl bg-white/95 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-xl">
            <CardTitle className="text-3xl font-bold text-center">تحميل الملفات</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <p className="text-lg text-gray-700 mb-8 text-center">
              يرجى تحميل ملفات Excel تحتوي على قوائم الأساتذة والتلاميذ. تأكد من أن كل ملف يحتوي على عمود واحد فقط مع
              أسماء الأساتذة أو التلاميذ.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex flex-col items-center">
                <label className="w-full cursor-pointer bg-blue-500 hover:bg-blue-600 text-white py-4 px-6 rounded-lg transition-colors duration-300 flex items-center justify-center">
                  <Upload className="mr-2 h-6 w-6" />
                  <span className="text-lg font-semibold">تحميل قائمة الأساتذة</span>
                  <input
                    type="file"
                    className="hidden"
                    accept=".xlsx, .xls"
                    onChange={(e) => handleFileUpload(e, "professors")}
                  />
                </label>
                {professorsFile && <p className="mt-2 text-green-600 font-semibold">{professorsFile.name}</p>}
              </div>
              <div className="flex flex-col items-center">
                <label className="w-full cursor-pointer bg-green-500 hover:bg-green-600 text-white py-4 px-6 rounded-lg transition-colors duration-300 flex items-center justify-center">
                  <Upload className="mr-2 h-6 w-6" />
                  <span className="text-lg font-semibold">تحميل قائمة التلاميذ</span>
                  <input
                    type="file"
                    className="hidden"
                    accept=".xlsx, .xls"
                    onChange={(e) => handleFileUpload(e, "students")}
                  />
                </label>
                {studentsFile && <p className="mt-2 text-green-600 font-semibold">{studentsFile.name}</p>}
              </div>
            </div>
            {error && <p className="mt-4 text-red-500 text-center font-semibold">{error}</p>}
            <div className="mt-8 flex justify-center">
              <Button
                onClick={handleImport}
                className="bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-8 rounded-lg text-lg font-semibold transition-colors duration-300"
                disabled={!professorsFile || !studentsFile || loading}
              >
                {loading ? "جاري الاستيراد..." : "استيراد البيانات"}
              </Button>
            </div>
            {loading && <p className="mt-4 text-blue-500 text-center font-semibold">جاري الاستيراد...</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

