"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Card, CardHeader, CardTitle, CardContent } from "./ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Upload } from "lucide-react"
import * as XLSX from "xlsx"
import type { SetupData } from "../types"

interface SetupFormProps {
  onSetupComplete: (data: SetupData) => void
  onNavigate: (page: string) => void
}

export function SetupForm({ onSetupComplete, onNavigate }: SetupFormProps) {
  const [educationLevel, setEducationLevel] = useState("")
  const [totalRooms, setTotalRooms] = useState("")
  const [professors, setProfessors] = useState<string[]>([])
  const [error, setError] = useState("")

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) {
      setError("الرجاء اختيار ملف Excel.")
      return
    }

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: "buffer" })
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const excelData = XLSX.utils.sheet_to_json(worksheet, { header: 1 })

      if (!excelData || excelData.length === 0) {
        setError("الملف فارغ أو لا يحتوي على بيانات.")
        return
      }

      const extractedProfessors = (excelData as string[][]).flat().filter(Boolean) as string[]

      if (extractedProfessors.length === 0) {
        setError("لم يتم العثور على أي أسماء أساتذة في الملف.")
        return
      }

      setProfessors(extractedProfessors)
      setError("")
    } catch (e) {
      setError("حدث خطأ أثناء قراءة الملف. الرجاء التأكد من أن الملف بتنسيق Excel صالح.")
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!educationLevel || !totalRooms || professors.length === 0) {
      setError("الرجاء ملء جميع الحقول وتحميل ملف الأساتذة.")
      return
    }
    const setupData: SetupData = {
      educationLevel,
      totalRooms: Number.parseInt(totalRooms),
      totalProfessors: professors.length,
      professors: professors,
    }
    onSetupComplete(setupData)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-indigo-800 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-white mb-8 text-center">إعداد توزيع الحراسة</h1>
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">إدخال البيانات</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="educationLevel">المستوى التعليمي</Label>
              <Select onValueChange={setEducationLevel} required>
                <SelectTrigger id="educationLevel">
                  <SelectValue placeholder="اختر المستوى التعليمي" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="primary">الابتدائي</SelectItem>
                  <SelectItem value="middle">المتوسط</SelectItem>
                  <SelectItem value="secondary">الثانوي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="totalRooms">العدد الكلي لقاعات الامتحان</Label>
              <Input
                id="totalRooms"
                type="number"
                placeholder="أدخل عدد القاعات"
                value={totalRooms}
                onChange={(e) => setTotalRooms(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="professorFile">قائمة الأساتذة (ملف Excel)</Label>
              <label className="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md transition-colors duration-200 flex items-center justify-center">
                <Upload className="mr-2 h-4 w-4" /> تحميل ملف الأساتذة
                <input
                  id="professorFile"
                  type="file"
                  className="hidden"
                  accept=".xlsx, .xls"
                  onChange={handleFileUpload}
                  required
                />
              </label>
              {professors.length > 0 && <p className="text-sm text-green-600">تم تحميل {professors.length} أستاذ</p>}
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <Button type="submit" className="w-full">
              بدء التوزيع
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

