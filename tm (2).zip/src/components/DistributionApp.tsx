"use client"

import { useState, useEffect } from "react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "./ui/table"
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "./ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Printer, FileSpreadsheet, Search, Users, School, Calendar } from "lucide-react"
import * as XLSX from "xlsx"
import { getDistributions, createDistribution, updateDistribution } from "../services/api"

interface DistributionAppProps {
  professors: string[]
  onNavigate: (page: string) => void
}

interface DayDistribution {
  day: number
  rooms: RoomAssignment[]
}

interface RoomAssignment {
  room: string
  professors: string[]
}

export function DistributionApp({ professors, onNavigate }: DistributionAppProps) {
  const [distributions, setDistributions] = useState<DayDistribution[]>([])
  const [error, setError] = useState<string>("")
  const [isDistributed, setIsDistributed] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [editMode, setEditMode] = useState(false)
  const [editedDistributions, setEditedDistributions] = useState<DayDistribution[]>([])
  const [totalRooms, setTotalRooms] = useState(0)
  const [educationLevel, setEducationLevel] = useState("")
  const [loading, setLoading] = useState(false)
  const [distributionId, setDistributionId] = useState<string | null>(null)

  const NUM_DAYS = 5
  const days = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"]

  // جلب التوزيعات المحفوظة من الخادم عند تحميل المكون
  useEffect(() => {
    const fetchDistributions = async () => {
      try {
        setLoading(true)
        const data = await getDistributions()

        if (data.length > 0) {
          const latestDistribution = data[data.length - 1]
          setDistributionId(latestDistribution.id)
          setDistributions(latestDistribution.days)
          setEditedDistributions(latestDistribution.days)
          setIsDistributed(true)

          // استخراج عدد الغرف من التوزيعات المحفوظة
          if (latestDistribution.days.length > 0 && latestDistribution.days[0].rooms.length > 0) {
            setTotalRooms(latestDistribution.days[0].rooms.length)
          }
        }
      } catch (error) {
        console.error("Error fetching distributions:", error)
        setError("حدث خطأ أثناء جلب البيانات من الخادم")
      } finally {
        setLoading(false)
      }
    }

    fetchDistributions()
  }, [])

  useEffect(() => {
    if (isDistributed) {
      setEditedDistributions([...distributions])
    }
  }, [isDistributed, distributions])

  const distributeProfessors = async () => {
    if (professors.length < totalRooms * 2) {
      setError(`عدد الأساتذة غير كافٍ. يجب أن يكون هناك على الأقل ${totalRooms * 2} أستاذًا.`)
      return
    }

    setLoading(true)
    try {
      const newDistributions: DayDistribution[] = []
      const professorAssignments: { [key: string]: Set<string> } = {}
      const pairAssignments: Set<string> = new Set()

      for (let day = 1; day <= NUM_DAYS; day++) {
        const dayDistribution: DayDistribution = { day, rooms: [] }
        const assignedProfessorsToday = new Set<string>()

        for (let i = 0; i < totalRooms; i++) {
          const room = `قاعة ${i + 1}`
          const availableProfessors = professors.filter(
            (p) => !assignedProfessorsToday.has(p) && (!professorAssignments[p] || !professorAssignments[p].has(room)),
          )

          if (availableProfessors.length < 2) {
            throw new Error("لا يمكن توزيع الأساتذة بشكل عادل. حاول زيادة عدد الأساتذة أو تقليل عدد القاعات.")
          }

          let professor1, professor2
          let attempts = 0
          const maxAttempts = 100

          do {
            professor1 = availableProfessors[Math.floor(Math.random() * availableProfessors.length)]
            professor2 = availableProfessors[Math.floor(Math.random() * availableProfessors.length)]
            attempts++

            if (attempts >= maxAttempts) {
              throw new Error("لم نتمكن من إيجاد توزيع مثالي. يرجى المحاولة مرة أخرى أو تعديل عدد الأساتذة أو القاعات.")
            }
          } while (
            professor1 === professor2 ||
            pairAssignments.has(`${professor1}-${professor2}`) ||
            pairAssignments.has(`${professor2}-${professor1}`)
          )

          dayDistribution.rooms.push({ room, professors: [professor1, professor2] })
          assignedProfessorsToday.add(professor1)
          assignedProfessorsToday.add(professor2)
          professorAssignments[professor1] = professorAssignments[professor1] || new Set()
          professorAssignments[professor2] = professorAssignments[professor2] || new Set()
          professorAssignments[professor1].add(room)
          professorAssignments[professor2].add(room)
          pairAssignments.add(`${professor1}-${professor2}`)
        }

        newDistributions.push(dayDistribution)
      }

      // حفظ التوزيعات في الخادم
      const response = await createDistribution(newDistributions)
      setDistributionId(response.id)

      setDistributions(newDistributions)
      setEditedDistributions(newDistributions)
      setIsDistributed(true)
      setError("")
    } catch (error) {
      console.error("Error distributing professors:", error)
      setError(error instanceof Error ? error.message : "حدث خطأ أثناء توزيع الأساتذة")
    } finally {
      setLoading(false)
    }
  }

  const handleProfessorChange = async (
    day: number,
    roomIndex: number,
    professorIndex: number,
    newProfessor: string,
  ) => {
    try {
      const newDistributions = [...editedDistributions]
      newDistributions[day - 1].rooms[roomIndex].professors[professorIndex] = newProfessor
      setEditedDistributions(newDistributions)

      // تحديث التوزيع في الخادم
      if (distributionId) {
        await updateDistribution(distributionId, newDistributions)
      }
    } catch (error) {
      console.error("Error updating distribution:", error)
      setError("حدث خطأ أثناء تحديث التوزيع")
    }
  }

  const exportToExcel = () => {
    if (!isDistributed) {
      setError("الرجاء توزيع الأساتذة أولاً.")
      return
    }

    const wb = XLSX.utils.book_new()
    const wsData = [
      ["اسم الأستاذ", ...days],
      ...professors.map((professor) => [
        professor,
        ...Array.from({ length: NUM_DAYS }, (_, day) => getProfessorRoom(professor, day + 1)),
      ]),
    ]
    const ws = XLSX.utils.aoa_to_sheet(wsData)
    XLSX.utils.book_append_sheet(wb, ws, "توزيع الأساتذة")
    XLSX.writeFile(wb, "توزيع_الأساتذة.xlsx")
  }

  const getProfessorRoom = (professor: string, day: number): string => {
    const dayDistribution = editedDistributions.find((d) => d.day === day)
    if (!dayDistribution) return "غير محدد"

    const room = dayDistribution.rooms.find((r) => r.professors.includes(professor))
    return room ? room.room : "غير محدد"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-800 to-indigo-900 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-5xl font-extrabold text-white mb-12 text-center tracking-tight">
          توزيع الأساتذة على قاعات الامتحان
        </h1>
        <Card className="shadow-2xl bg-white/95 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-xl">
            <CardTitle className="text-3xl font-bold text-center">إعداد التوزيع</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            {loading && <p className="text-center text-blue-500 font-semibold mb-4">جاري تحميل البيانات...</p>}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
              <Card className="bg-blue-50 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="flex items-center justify-between p-6">
                  <div className="flex items-center space-x-4">
                    <School className="h-10 w-10 text-blue-600" />
                    <div>
                      <p className="text-sm font-medium text-blue-600">المستوى التعليمي</p>
                      <Select onValueChange={setEducationLevel} value={educationLevel}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="اختر المستوى" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="primary">الابتدائي</SelectItem>
                          <SelectItem value="middle">المتوسط</SelectItem>
                          <SelectItem value="secondary">الثانوي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-green-50 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="flex items-center justify-between p-6">
                  <div className="flex items-center space-x-4">
                    <Users className="h-10 w-10 text-green-600" />
                    <div>
                      <p className="text-sm font-medium text-green-600">عدد الأساتذة</p>
                      <p className="text-2xl font-bold text-green-900">{professors.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-purple-50 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="flex items-center justify-between p-6">
                  <div className="flex items-center space-x-4">
                    <Calendar className="h-10 w-10 text-purple-600" />
                    <div>
                      <p className="text-sm font-medium text-purple-600">عدد القاعات</p>
                      <Input
                        type="number"
                        value={totalRooms}
                        onChange={(e) => setTotalRooms(Number.parseInt(e.target.value))}
                        className="w-20 text-2xl font-bold text-purple-900"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-center mb-8">
              <Button
                onClick={distributeProfessors}
                className="bg-indigo-600 hover:bg-indigo-700 text-white"
                disabled={loading}
              >
                {loading ? "جاري التوزيع..." : "توزيع الأساتذة"}
              </Button>
            </div>

            {error && (
              <div className="text-center font-bold mb-8 p-4 rounded-lg bg-red-100 text-red-800 shadow-md">{error}</div>
            )}

            {isDistributed && (
              <>
                <div className="mb-8">
                  <Label htmlFor="search" className="text-xl font-semibold text-gray-700 mb-2 block">
                    البحث عن أستاذ
                  </Label>
                  <div className="relative">
                    <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <Input
                      id="search"
                      type="text"
                      placeholder="أدخل اسم الأستاذ..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-12 pr-4 py-3 text-lg rounded-full border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-300"
                    />
                  </div>
                </div>

                <div className="flex justify-between mb-4">
                  <Button
                    onClick={() => setEditMode(!editMode)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white"
                  >
                    {editMode ? "إنهاء التعديل" : "تعديل التوزيع"}
                  </Button>
                </div>

                <div className="overflow-x-auto rounded-xl shadow-xl border border-gray-200">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gradient-to-r from-blue-600 to-indigo-600">
                        <TableHead className="text-lg font-bold text-white py-4">اسم الأستاذ</TableHead>
                        {days.map((day) => (
                          <TableHead key={day} className="text-lg font-bold text-white py-4">
                            {day}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {professors
                        .filter((professor) => professor.toLowerCase().includes(searchTerm.toLowerCase()))
                        .map((professor, index) => (
                          <TableRow
                            key={index}
                            className={
                              index % 2 === 0
                                ? "bg-white"
                                : "bg-gray-50 hover:bg-blue-50 transition-colors duration-150"
                            }
                          >
                            <TableCell className="font-medium text-gray-900 py-4">{professor}</TableCell>
                            {Array.from({ length: NUM_DAYS }, (_, day) => (
                              <TableCell key={day} className="py-4">
                                {editMode ? (
                                  <Select
                                    onValueChange={(value) => {
                                      const dayDistribution = editedDistributions[day]
                                      const roomIndex = dayDistribution.rooms.findIndex((r) =>
                                        r.professors.includes(professor),
                                      )
                                      if (roomIndex !== -1) {
                                        const professorIndex =
                                          dayDistribution.rooms[roomIndex].professors.indexOf(professor)
                                        handleProfessorChange(day + 1, roomIndex, professorIndex, value)
                                      }
                                    }}
                                    value={getProfessorRoom(professor, day + 1)}
                                  >
                                    <SelectTrigger className="w-[180px]">
                                      <SelectValue placeholder="اختر القاعة" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {Array.from({ length: totalRooms }, (_, i) => (
                                        <SelectItem key={i} value={`قاعة ${i + 1}`}>
                                          قاعة {i + 1}
                                        </SelectItem>
                                      ))}
                                      <SelectItem value="غير محدد">غير محدد</SelectItem>
                                    </SelectContent>
                                  </Select>
                                ) : (
                                  <span className="inline-block bg-blue-100 text-blue-800 rounded-full px-4 py-2 text-sm font-semibold shadow-sm">
                                    {getProfessorRoom(professor, day + 1)}
                                  </span>
                                )}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
          </CardContent>
          <CardFooter className="flex justify-center gap-8 mt-8 bg-gray-50 p-8 rounded-b-xl">
            <Button
              onClick={() => window.print()}
              className="bg-gray-700 hover:bg-gray-800 text-white flex items-center px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              <Printer className="mr-3 h-6 w-6" /> طباعة
            </Button>
            <Button
              onClick={exportToExcel}
              className="bg-green-600 hover:bg-green-700 text-white flex items-center px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              <FileSpreadsheet className="mr-3 h-6 w-6" /> تصدير إلى Excel
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

