"use client"

import { useState, useEffect } from "react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "./ui/table"
import { Card, CardHeader, CardTitle, CardContent } from "./ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { UserX, Clock, ClipboardList, Search } from "lucide-react"
import { getAbsences, addAbsence } from "../services/api"

interface AbsenceManagementProps {
  professors: string[]
  students: string[]
}

interface Absence {
  id: string
  name: string
  date: string
  type: "absence" | "late"
  category: "professor" | "student"
}

export function AbsenceManagement({ professors, students }: AbsenceManagementProps) {\
  const [activeTab, setActiveTabprofessors, students}: AbsenceManagementProps) {
  const [activeTab, setActiveTab] = useState<"professors" | "students">("professors")
  const [absences, setAbsences] = useState<Absence[]>([])
  const [showAbsenceList, setShowAbsenceList] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(false)

  // جلب بيانات الغيابات من الخادم عند تحميل المكون
  useEffect(() => {
    const fetchAbsences = async () => {
      try {
        setLoading(true)
        const data = await getAbsences()
        setAbsences(data)
      } catch (error) {
        console.error("Error fetching absences:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAbsences()
  }, [])

  const handleAbsence = async (name: string, type: "absence" | "late", category: "professor" | "student") => {
    try {
      setLoading(true)
      const newAbsence = await addAbsence(name, type, category)
      setAbsences((prev) => [...prev, newAbsence])
    } catch (error) {
      console.error("Error recording absence:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredProfessors = professors.filter((prof) => prof.toLowerCase().includes(searchTerm.toLowerCase()))
  const filteredStudents = students.filter((student) => student.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-800 to-indigo-900 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-5xl font-extrabold text-white mb-12 text-center tracking-tight">تسيير الغيابات</h1>
        <Card className="shadow-2xl bg-white/95 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-xl">
            <CardTitle className="text-3xl font-bold text-center">إدارة الغيابات والتأخيرات</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            {loading && <p className="text-center text-blue-500 font-semibold mb-4">جاري تحميل البيانات...</p>}

            <div className="flex justify-between mb-6">
              <Button
                onClick={() => setShowAbsenceList(!showAbsenceList)}
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                <ClipboardList className="mr-2 h-5 w-5" />
                {showAbsenceList ? "العودة إلى التسجيل" : "متابعة الغيابات المسجلة"}
              </Button>
            </div>

            {showAbsenceList ? (
              <AbsenceList absences={absences} />
            ) : (
              <>
                <div className="mb-6">
                  <div className="relative">
                    <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <Input
                      type="text"
                      placeholder="البحث..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-12 pr-4 py-3 text-lg rounded-full border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-300"
                    />
                  </div>
                </div>

                <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "professors" | "students")}>
                  <TabsList className="grid w-full grid-cols-2 mb-8">
                    <TabsTrigger value="professors">الأساتذة</TabsTrigger>
                    <TabsTrigger value="students">التلاميذ</TabsTrigger>
                  </TabsList>
                  <TabsContent value="professors">
                    <AttendanceTable
                      title="قائمة الأساتذة"
                      data={filteredProfessors}
                      onAbsence={(name) => handleAbsence(name, "absence", "professor")}
                      onLate={(name) => handleAbsence(name, "late", "professor")}
                    />
                  </TabsContent>
                  <TabsContent value="students">
                    <AttendanceTable
                      title="قائمة التلاميذ"
                      data={filteredStudents}
                      onAbsence={(name) => handleAbsence(name, "absence", "student")}
                      onLate={(name) => handleAbsence(name, "late", "student")}
                    />
                  </TabsContent>
                </Tabs>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

interface AttendanceTableProps {
  title: string
  data: string[]
  onAbsence: (name: string) => void
  onLate: (name: string) => void
}

function AttendanceTable({ title, data, onAbsence, onLate }: AttendanceTableProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <div className="overflow-x-auto rounded-xl shadow-xl border border-gray-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-blue-600 to-indigo-600">
              <TableHead className="text-lg font-bold text-white py-4">الاسم</TableHead>
              <TableHead className="text-lg font-bold text-white py-4">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((name, index) => (
              <TableRow
                key={index}
                className={index % 2 === 0 ? "bg-white" : "bg-gray-50 hover:bg-blue-50 transition-colors duration-150"}
              >
                <TableCell className="font-medium text-gray-900 py-4">{name}</TableCell>
                <TableCell className="py-4">
                  <div className="flex space-x-2">
                    <Button onClick={() => onAbsence(name)} className="bg-red-500 hover:bg-red-600 text-white">
                      <UserX className="mr-2 h-4 w-4" />
                      تسجيل الغياب
                    </Button>
                    <Button onClick={() => onLate(name)} className="bg-yellow-500 hover:bg-yellow-600 text-white">
                      <Clock className="mr-2 h-4 w-4" />
                      تسجيل التأخر
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

interface AbsenceListProps {
  absences: Absence[]
}

function AbsenceList({ absences }: AbsenceListProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">قائمة الغيابات والتأخيرات</h2>
      <div className="overflow-x-auto rounded-xl shadow-xl border border-gray-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-blue-600 to-indigo-600">
              <TableHead className="text-lg font-bold text-white py-4">الاسم</TableHead>
              <TableHead className="text-lg font-bold text-white py-4">التاريخ</TableHead>
              <TableHead className="text-lg font-bold text-white py-4">النوع</TableHead>
              <TableHead className="text-lg font-bold text-white py-4">الفئة</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {absences.map((absence, index) => (
              <TableRow
                key={index}
                className={index % 2 === 0 ? "bg-white" : "bg-gray-50 hover:bg-blue-50 transition-colors duration-150"}
              >
                <TableCell className="font-medium text-gray-900 py-4">{absence.name}</TableCell>
                <TableCell className="py-4">{new Date(absence.date).toLocaleDateString("ar-EG")}</TableCell>
                <TableCell className="py-4">
                  <span
                    className={`px-2 py-1 rounded-full ${
                      absence.type === "absence" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"
                    }`}
                  >
                    {absence.type === "absence" ? "غياب" : "تأخر"}
                  </span>
                </TableCell>
                <TableCell className="py-4">{absence.category === "professor" ? "أستاذ" : "تلميذ"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

