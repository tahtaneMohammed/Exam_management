// تعريفات الأنواع المستخدمة في التطبيق

// نوع بيانات الإعداد
export interface SetupData {
  educationLevel: string
  totalRooms: number
  totalProfessors: number
  professors: string[]
}

// نوع بيانات توزيع القاعات
export interface RoomAssignment {
  room: string
  professors: string[]
}

// نوع بيانات توزيع اليوم
export interface DayDistribution {
  day: number
  rooms: RoomAssignment[]
}

// نوع بيانات الغياب
export interface Absence {
  id: string
  name: string
  date: string
  type: "absence" | "late"
  category: "professor" | "student"
}

// نوع بيانات الأستاذ
export interface Professor {
  id: string
  name: string
  createdAt: string
}

// نوع بيانات الطالب
export interface Student {
  id: string
  name: string
  createdAt: string
}

// نوع بيانات التوزيع
export interface Distribution {
  id: string
  days: DayDistribution[]
  createdAt: string
  updatedAt?: string
}

