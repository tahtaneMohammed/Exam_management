const fs = require("fs")
const path = require("path")

const DATA_DIR = path.join(__dirname, "..", "data")
const PROFESSORS_FILE = path.join(DATA_DIR, "professors.json")
const STUDENTS_FILE = path.join(DATA_DIR, "students.json")
const ABSENCES_FILE = path.join(DATA_DIR, "absences.json")
const DISTRIBUTIONS_FILE = path.join(DATA_DIR, "distributions.json")

// قراءة البيانات من ملف
const readDataFromFile = (filePath) => {
  try {
    const data = fs.readFileSync(filePath, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error(`خطأ في قراءة الملف ${filePath}:`, error)
    return []
  }
}

// كتابة البيانات إلى ملف
const writeDataToFile = (filePath, data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8")
    return true
  } catch (error) {
    console.error(`خطأ في كتابة الملف ${filePath}:`, error)
    return false
  }
}

// إنشاء معرف فريد
const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
}

module.exports = {
  DATA_DIR,
  PROFESSORS_FILE,
  STUDENTS_FILE,
  ABSENCES_FILE,
  DISTRIBUTIONS_FILE,
  readDataFromFile,
  writeDataToFile,
  generateId,
}

