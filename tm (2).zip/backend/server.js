const express = require("express")
const cors = require("cors")
const bodyParser = require("body-parser")
const fs = require("fs")
const path = require("path")

// إنشاء تطبيق Express
const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(bodyParser.json())

// مسار لحفظ البيانات
const DATA_DIR = path.join(__dirname, "data")
const PROFESSORS_FILE = path.join(DATA_DIR, "professors.json")
const STUDENTS_FILE = path.join(DATA_DIR, "students.json")
const ABSENCES_FILE = path.join(DATA_DIR, "absences.json")
const DISTRIBUTIONS_FILE = path.join(DATA_DIR, "distributions.json")

// التأكد من وجود مجلد البيانات
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true })
}

// إنشاء ملفات البيانات إذا لم تكن موجودة
const initializeDataFile = (filePath, initialData = []) => {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2))
  }
}

initializeDataFile(PROFESSORS_FILE)
initializeDataFile(STUDENTS_FILE)
initializeDataFile(ABSENCES_FILE)
initializeDataFile(DISTRIBUTIONS_FILE)

// استيراد المسارات
const professorsRoutes = require("./routes/professors")
const studentsRoutes = require("./routes/students")
const absencesRoutes = require("./routes/absences")
const distributionsRoutes = require("./routes/distributions")

// استخدام المسارات
app.use("/api/professors", professorsRoutes)
app.use("/api/students", studentsRoutes)
app.use("/api/absences", absencesRoutes)
app.use("/api/distributions", distributionsRoutes)

// مسار الاختبار
app.get("/", (req, res) => {
  res.json({ message: "مرحبًا بك في واجهة برمجة تطبيق إدارة الامتحانات" })
})

// تشغيل الخادم
app.listen(PORT, () => {
  console.log(`الخادم يعمل على المنفذ ${PORT}`)
})

module.exports = app

