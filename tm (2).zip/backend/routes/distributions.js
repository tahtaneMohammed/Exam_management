const express = require("express")
const router = express.Router()
const {
  DISTRIBUTIONS_FILE,
  PROFESSORS_FILE,
  readDataFromFile,
  writeDataToFile,
  generateId,
} = require("../utils/fileUtils")

// الحصول على جميع التوزيعات
router.get("/", (req, res) => {
  const distributions = readDataFromFile(DISTRIBUTIONS_FILE)
  res.json(distributions)
})

// إنشاء توزيع جديد
router.post("/", (req, res) => {
  const { days } = req.body

  if (!days || !Array.isArray(days)) {
    return res.status(400).json({ error: "بيانات التوزيع غير صحيحة" })
  }

  const newDistribution = {
    id: generateId(),
    days,
    createdAt: new Date().toISOString(),
  }

  const distributions = readDataFromFile(DISTRIBUTIONS_FILE)
  distributions.push(newDistribution)
  writeDataToFile(DISTRIBUTIONS_FILE, distributions)

  res.status(201).json(newDistribution)
})

// تحديث توزيع موجود
router.put("/:id", (req, res) => {
  const { id } = req.params
  const { days } = req.body

  if (!days || !Array.isArray(days)) {
    return res.status(400).json({ error: "بيانات التوزيع غير صحيحة" })
  }

  const distributions = readDataFromFile(DISTRIBUTIONS_FILE)
  const index = distributions.findIndex((d) => d.id === id)

  if (index === -1) {
    return res.status(404).json({ error: "التوزيع غير موجود" })
  }

  distributions[index] = {
    ...distributions[index],
    days,
    updatedAt: new Date().toISOString(),
  }

  writeDataToFile(DISTRIBUTIONS_FILE, distributions)
  res.json(distributions[index])
})

// حذف جميع التوزيعات
router.delete("/", (req, res) => {
  writeDataToFile(DISTRIBUTIONS_FILE, [])
  res.json({ message: "تم حذف جميع التوزيعات بنجاح" })
})

module.exports = router

