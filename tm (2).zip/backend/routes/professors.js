const express = require("express")
const router = express.Router()
const { PROFESSORS_FILE, readDataFromFile, writeDataToFile, generateId } = require("../utils/fileUtils")

// الحصول على جميع الأساتذة
router.get("/", (req, res) => {
  const professors = readDataFromFile(PROFESSORS_FILE)
  res.json(professors)
})

// إضافة أستاذ جديد
router.post("/", (req, res) => {
  const professors = readDataFromFile(PROFESSORS_FILE)
  const { name } = req.body

  if (!name) {
    return res.status(400).json({ error: "اسم الأستاذ مطلوب" })
  }

  // التحقق من عدم وجود الأستاذ مسبقًا
  const existingProfessor = professors.find((p) => p.name === name)
  if (existingProfessor) {
    return res.status(400).json({ error: "الأستاذ موجود بالفعل" })
  }

  const newProfessor = {
    id: generateId(),
    name,
    createdAt: new Date().toISOString(),
  }

  professors.push(newProfessor)
  writeDataToFile(PROFESSORS_FILE, professors)

  res.status(201).json(newProfessor)
})

// إضافة مجموعة من الأساتذة
router.post("/batch", (req, res) => {
  let professors = readDataFromFile(PROFESSORS_FILE)
  const { names } = req.body

  if (!names || !Array.isArray(names)) {
    return res.status(400).json({ error: "قائمة أسماء الأساتذة مطلوبة" })
  }

  const newProfessors = []
  const existingNames = professors.map((p) => p.name)

  for (const name of names) {
    if (!existingNames.includes(name)) {
      const newProfessor = {
        id: generateId(),
        name,
        createdAt: new Date().toISOString(),
      }
      newProfessors.push(newProfessor)
      existingNames.push(name)
    }
  }

  professors = [...professors, ...newProfessors]
  writeDataToFile(PROFESSORS_FILE, professors)

  res.status(201).json({
    message: `تمت إضافة ${newProfessors.length} أستاذ بنجاح`,
    professors: newProfessors,
  })
})

// حذف جميع الأساتذة
router.delete("/", (req, res) => {
  writeDataToFile(PROFESSORS_FILE, [])
  res.json({ message: "تم حذف جميع الأساتذة بنجاح" })
})

module.exports = router

