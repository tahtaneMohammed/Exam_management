const express = require("express")
const router = express.Router()
const { STUDENTS_FILE, readDataFromFile, writeDataToFile, generateId } = require("../utils/fileUtils")

// الحصول على جميع الطلاب
router.get("/", (req, res) => {
  const students = readDataFromFile(STUDENTS_FILE)
  res.json(students)
})

// إضافة طالب جديد
router.post("/", (req, res) => {
  const students = readDataFromFile(STUDENTS_FILE)
  const { name } = req.body

  if (!name) {
    return res.status(400).json({ error: "اسم الطالب مطلوب" })
  }

  // التحقق من عدم وجود الطالب مسبقًا
  const existingStudent = students.find((s) => s.name === name)
  if (existingStudent) {
    return res.status(400).json({ error: "الطالب موجود بالفعل" })
  }

  const newStudent = {
    id: generateId(),
    name,
    createdAt: new Date().toISOString(),
  }

  students.push(newStudent)
  writeDataToFile(STUDENTS_FILE, students)

  res.status(201).json(newStudent)
})

// إضافة مجموعة من الطلاب
router.post("/batch", (req, res) => {
  let students = readDataFromFile(STUDENTS_FILE)
  const { names } = req.body

  if (!names || !Array.isArray(names)) {
    return res.status(400).json({ error: "قائمة أسماء الطلاب مطلوبة" })
  }

  const newStudents = []
  const existingNames = students.map((s) => s.name)

  for (const name of names) {
    if (!existingNames.includes(name)) {
      const newStudent = {
        id: generateId(),
        name,
        createdAt: new Date().toISOString(),
      }
      newStudents.push(newStudent)
      existingNames.push(name)
    }
  }

  students = [...students, ...newStudents]
  writeDataToFile(STUDENTS_FILE, students)

  res.status(201).json({
    message: `تمت إضافة ${newStudents.length} طالب بنجاح`,
    students: newStudents,
  })
})

// حذف جميع الطلاب
router.delete("/", (req, res) => {
  writeDataToFile(STUDENTS_FILE, [])
  res.json({ message: "تم حذف جميع الطلاب بنجاح" })
})

module.exports = router

