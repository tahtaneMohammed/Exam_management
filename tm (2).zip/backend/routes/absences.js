const express = require("express")
const router = express.Router()
const {
  ABSENCES_FILE,
  PROFESSORS_FILE,
  STUDENTS_FILE,
  readDataFromFile,
  writeDataToFile,
  generateId,
} = require("../utils/fileUtils")

// الحصول على جميع الغيابات
router.get("/", (req, res) => {
  const absences = readDataFromFile(ABSENCES_FILE)
  res.json(absences)
})

// إضافة غياب جديد
router.post("/", (req, res) => {
  const absences = readDataFromFile(ABSENCES_FILE)
  const professors = readDataFromFile(PROFESSORS_FILE)
  const students = readDataFromFile(STUDENTS_FILE)

  const { name, type, category } = req.body

  if (!name || !type || !category) {
    return res.status(400).json({ error: "جميع الحقول مطلوبة (الاسم، النوع، الفئة)" })
  }

  if (type !== "absence" && type !== "late") {
    return res.status(400).json({ error: 'نوع الغياب يجب أن يكون "absence" أو "late"' })
  }

  if (category !== "professor" && category !== "student") {
    return res.status(400).json({ error: 'الفئة يجب أن تكون "professor" أو "student"' })
  }

  let personId = null

  if (category === "professor") {
    const professor = professors.find((p) => p.name === name)
    if (!professor) {
      return res.status(404).json({ error: "الأستاذ غير موجود" })
    }
    personId = professor.id
  } else {
    const student = students.find((s) => s.name === name)
    if (!student) {
      return res.status(404).json({ error: "الطالب غير موجود" })
    }
    personId = student.id
  }

  const newAbsence = {
    id: generateId(),
    personId,
    name,
    date: new Date().toISOString(),
    type,
    category,
    createdAt: new Date().toISOString(),
  }

  absences.push(newAbsence)
  writeDataToFile(ABSENCES_FILE, absences)

  res.status(201).json(newAbsence)
})

// حذف جميع الغيابات
router.delete("/", (req, res) => {
  writeDataToFile(ABSENCES_FILE, [])
  res.json({ message: "تم حذف جميع الغيابات بنجاح" })
})

module.exports = router

