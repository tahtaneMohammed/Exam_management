"use client"

import  from "../src/components/ui/dialog"

export default function SyntheticV0PageForDeployment() {
  return < />
}